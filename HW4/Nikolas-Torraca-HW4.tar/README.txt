HW4: CPU Scheduling Algorithms
Nikolas Torraca

1. No, SRTF is preemptive.
2. New, Ready, Running, Waiting, Terminated
3. Burst Time
4. Convoy effect is the primary disadvantage of FCFS.
5. With a multileve feedback queue, processes can move between the various queues. So a process could be upgraded to a higher priority queue.